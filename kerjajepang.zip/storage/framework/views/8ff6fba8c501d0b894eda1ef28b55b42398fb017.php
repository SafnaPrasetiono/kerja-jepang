<div>
    
</div>
<?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/pages/news/comment.blade.php ENDPATH**/ ?>