<div>
    <div class="d-flex mb-3">
        <div class="ms-auto">
            <input type="text" class="form-control" placeholder="Cari Data...">
        </div>
    </div>
    <div class="d-block">
        <table class="table table-borderless">
            <thead class="alert-secondary">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Tanggal Lamaran</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($index + 1); ?></th>
                    
                    <td><?php echo e($item->title); ?></td>
                    <td>
                        <?php echo e(date("d F Y", strtotime($item->created_at))); ?>

                    </td>
                    <td>
                        <a href="#" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-pencil-alt fa-sm fa-fw"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex align-items-center">
        <p class="mb-0 border py-1 px-2 rounded">
            <span class="fw-bold"><?php echo e($data->count()); ?></span>
        </p>
        <?php if($data->hasPages()): ?>
        <nav class="ms-auto">
            <?php echo e($data->links('livewire.admin.loker.paginations')); ?>

        </nav>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/admin/proposal/data.blade.php ENDPATH**/ ?>