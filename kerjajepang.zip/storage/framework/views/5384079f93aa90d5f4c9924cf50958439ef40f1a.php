

<?php $__env->startSection('head'); ?>
    <title>kopitu - Selemat datang di kerjajepang.com</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
    <div class="box-auth">
        <div class="box-head">
            <h3 class="text-orange fw-bold">MASUK</h3>
            <p class="mb-0">Selamat datang di Kerja Jepang</p>
        </div>
        <div class="box-body">
            <form method="POST" action="<?php echo e(route('login.post')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <label for="Email" class="form-label">Email Anda</label>
                    <input name="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-2">
                    <label for="Password" class="form-label">Password</label>
                    <input name="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="d-flex justify-content-between mb-3">
                    
                    <a href="<?php echo e(route('password.set')); ?>" class="link-orange text-decoration-none ms-auto me-1">Get Password?</a>
                </div>
                <button type="submit" class="btn btn-outline-secondary form-control">MASUK</button>
            </form>
        </div>
        <div class="box-footer">
            <div class="d-block mb-3 text-center text-secondary">
                <span>-- ATAU --</span>
            </div>
            <div class="d-block mb-4">
                <div class="d-flex justify-content-center align-items-center">
                    <a href="<?php echo e(route('login.google')); ?>" class="btn btn-outline-secondary align-items-center w-100">
                        <img src="<?php echo e(url('/images/icons/google.png')); ?>" alt="google" width="24px"> Login dengan google
                    </a>
                </div>
            </div>
            <div class="d-block text-center text-secondary">
                <p class="mb-0">Tidak punya akun klik dibawah sini.</p>
                <a href="<?php echo e(route('register')); ?>" class="link-orange text-decoration-none text-uppercase">SignUp</a>
            </div>
        </div>
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/auth/login.blade.php ENDPATH**/ ?>