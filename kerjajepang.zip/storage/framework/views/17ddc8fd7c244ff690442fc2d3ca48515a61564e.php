

<?php $__env->startSection('head'); ?>
<title>kerjajepang - lowongan kerja</title>
<style>
    .ck-editor__editable {
        min-height: 200px;
        box-shadow: unset !important;
        border-radius: 0px 0px 4px 4px !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="container-fluid">
    <div class="d-block bg-white rounded shadow p-3 mb-3">
        <div class="row">
            <div class="col-12 col-sm-5 col-md-4 col-lg-3">
                <img src="<?php echo e(url('/images/loker/'.$loker->images)); ?>" alt="" class="img-fluid">
            </div>
            <div class="col-12 col-sm-7 col-md-8 col-lg-9">
                <div class="p-3 p-sm-0">
                    <p class="fs-5 fw-bold mb-2"><?php echo e($loker->title); ?></p>
                    <p class="mb-0 text-secondary"><?php echo e(date('d F Y', strtotime($loker->date_start))); ?> - <?php echo e(date('d F Y',
                        strtotime($loker->date_end))); ?></p>
                    <p class="text-secondary mb-0"><?php echo e($loker->locations); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="d-block bg-white rounded shadow mb-3">
        <div class="d-block p-3 border-bottom">
            <p class="mb-0 fw-bold">Detail Pelamar pekerjaan</p>
        </div>
        <div class="d-flex align-items-center p-3">
            <?php if($user->avatar == 'sample-avatar.png'): ?>
            <img src="<?php echo e(url('/images/avatar/' . $user->avatar )); ?>" class="rounded-circle" width="58px" height="58px">
            <?php else: ?>
            <img src="<?php echo e(url('/images/avatar/user/' . $user->avatar )); ?>" class="rounded-circle" width="58px"
                height="58px">
            <?php endif; ?>
            <div class="ms-3">
                <p class="fw-bold mb-0"><?php echo e($user->username); ?></p>
                <p class="mb-0"><?php echo e($user->email); ?></p>
            </div>
            <a href="<?php echo e(route('index.user.public', ['key' => $userPublic->key])); ?>" class="btn text-primary ms-auto">
                <i class="fas fa-globe fa-lg fa-fw"></i>
            </a>
        </div>
    </div>

    <div class="d-block bg-white rounded shadow mb-3">
        <div class="d-block p-3 border-bottom">
            <p class="mb-0 fw-bold">Kirimkan Aksi</p>
        </div>
        <div class="p-3">
            <form method="POST" action="<?php echo e(route('admin.loker.pelamar.action', ['id' => $data->id_proposal])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select name="status" id="status" class="form-select">
                        <option value="process" <?php if($data->status == 'process'): ?> selected <?php endif; ?>>process</option>
                        <option value="review" <?php if($data->status == 'review'): ?> selected <?php endif; ?>>review</option>
                        <option value="interview" <?php if($data->status == 'interview'): ?> selected <?php endif; ?>>Interview</option>
                        <option value="accepted" <?php if($data->status == 'accepted'): ?> selected <?php endif; ?>>accepted</option>
                        <option value="rejected" <?php if($data->status == 'rejected'): ?> selected <?php endif; ?>>rejected</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="editor" class="form-label">Beritahu User</label>
                    <textarea name="content" id="editors" rows="5"
                        class="form-control"><?php if($data->content != null): ?> <?php echo e($data->content); ?> <?php endif; ?></textarea>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary px-5">Send<i class="fas fa-arrow-alt-right ms-2"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/dist/ckeditor5/ckeditor.js')); ?>"></script>
    <script>
        ClassicEditor.create(document.querySelector("#editors"))
            .then((newEditor) => {
                editor = newEditor;
            })
            .catch((error) => {
                console.error(error);
            });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/loker/proposalDetail.blade.php ENDPATH**/ ?>