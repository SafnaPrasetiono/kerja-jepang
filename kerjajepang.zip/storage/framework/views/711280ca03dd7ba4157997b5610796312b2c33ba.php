<div>
    <div class="d-block bg-white rounded shadow mb-4">
        <div class="d-flex align-items-center px-4 py-3 border-bottom">
            <p class="fs-4 fw-bold mb-0">Tantang Saya</p>
            <button wire:click='edit' type="button" class="btn link-primary text-decoration-none ms-auto">
                <i class="fas fa-pencil-alt fa-sm fa-fw"></i> Edit
            </button>
        </div>
        <div class="p-4">
            <?php if($aboutUser == null): ?>
                <p class="mb-0"></p>
            <?php else: ?>
            <p class="mb-0"><?php echo e($aboutUser->about); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div wire:ignore.self class="modal fade" id="aboutModal" data-bs-backdrop="static" data-bs-keyboard="false"
    tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Tentang Saya</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3 placeholder-glow">
                    <label class="form-label" for="aboutMe">Beritahu tentang dirimu sehingga perusahaan lebih mudah memahamimu.</label>
                    <textarea wire:model='aboutMe' id="aboutMe" rows="5" class="form-control <?php $__errorArgs = ['aboutMe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:target="update"
                    wire:loading.class="placeholder disabled"></textarea>
                    <?php $__errorArgs = ['aboutMe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-primary" wire:click="update" wire:loading.attr="disabled">
                    <span wire:target="update" wire:loading class="spinner-border spinner-border-sm"></span>
                    Simpan
                </button>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(url('/dist/style/js/jquery.js')); ?>"></script>
<script>
    document.addEventListener('deleteConfrimed', function() {
        Swal.fire({
                title: "Apa anda yakin?",
                text: "Menghapus produk pesanan anda!!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: 'Yes, delete!',
                cancelButtonText: 'Tidak',
            })
            .then((next) => {
                if (next.isConfirmed) {
                    Livewire.emit('deleteAction');
                }
            });
    })

    document.addEventListener('editAbout', function() {
        $('#aboutModal').modal('show');
    });

    document.addEventListener('expandAbout', function() {
        $('#aboutModal').modal('hide');
    });
</script>

<?php if(session()->has('success')): ?>
<script>
    Swal.fire({
    icon: 'success',
    title: 'Good Jobs!',
    text: '<?php echo e(session()->get("success")); ?>',
    showConfirmButton: false,
    timer: 2500
})
</script>
<?php elseif(session()->has('error')): ?>
<script>
    Swal.fire({
    icon: 'error',
    title: 'Opps...!',
    text: '<?php echo e(session()->get("error")); ?>',
    showConfirmButton: false,
    timer: 2500
})
</script>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/user/about.blade.php ENDPATH**/ ?>