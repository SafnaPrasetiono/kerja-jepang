

<?php $__env->startSection('head'); ?>
    <title>kopitu - Selemat datang di kopitu e-store</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
    <div class="box-auth">
        <div class="box-head text-center pt-5">
            <div class="lh-sm mb-4">
                <?php if($user->avatar === 'sample-avatar.png'): ?>
                <img src="<?php echo e(url('/images/avatar/'. $user->avatar)); ?>" alt="<?php echo e($user->username); ?>" width="64px" height="64px" class="rounded-circle mb-2">
                <?php else: ?>
                <img src="<?php echo e(url('/images/avatar/user/'. $user->avatar)); ?>" alt="<?php echo e($user->username); ?>" width="64px" height="64px" class="rounded-circle mb-2">
                <?php endif; ?>
                <p class="fw-bold mb-0"><?php echo e($user->username); ?></p>
                <p class="fw-bold text-secondary"><?php echo e($user->email); ?></p>
            </div>
            
            <p class="mb-0">Password baru kamu harus berbeda dari akun password sebelumnya.</p>
        </div>
        <div class="box-body pt-3 pb-4">
            <form method="POST" action="<?php echo e(route('password.post.reset.action')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <input name="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="Password" placeholder="Password">
                </div>
                <div class="mb-4">
                    <input name="password_confirmation" type="password" name="password"
                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Confirmation Password">
                </div>
                <input type="hidden" class="d-none" name="id_users" value="<?php echo e($user->id_users); ?>">
                <button type="submit" class="btn btn-primary form-control my-3">RESET PASSWORD</button>
            </form>
        </div>
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/auth/passwordReset.blade.php ENDPATH**/ ?>