<div>
        <div id="carouselBanners" class="carousel slide" data-bs-ride="carousel">
            
            <div class="carousel-inner">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php if($index == 0): ?> active <?php endif; ?>">
                    <img src="<?php echo e(url('/images/banner/' . $item->banners_sm)); ?>"
                        class="d-block d-md-none w-100" alt="banners-1">
                    <img src="<?php echo e(url('/images/banner/' . $item->banners_lg)); ?>"
                        class="d-none d-md-block w-100" alt="banners-1">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselBanners" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselBanners" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/pages/index/banner.blade.php ENDPATH**/ ?>