<div>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="d-flex flex-column flex-sm-row lign-items-center g-0 border rounded overflow-hidden position-relative">
        <div class="col-12 col-sm-5 col-lg-4">
            <img src="<?php echo e(url('/images/loker/' . $item->images )); ?>" class="img-fluid">
        </div>
        <div class="col-12 col-sm-7 col-lg-8">
            <div class="d-block p-3">
                <p class="fs-5 fw-bold mb-0 lh-sm text-ellipsis-2"><?php echo e($item->title); ?></p>
                <p class="card-text mb-3">Dikirim pada, <?php echo e(date('d F Y', strtotime($item->created_at))); ?></p>
                <span class="rounded-pill px-3 py-1 text-white bg-warning">Interview</span>
            </div>
        </div>
        <a href="<?php echo e(route('user.lamaran.detail', ['id' => $item->id_proposal])); ?>" class="btn btn-primary stretched-link"></a>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/user/lamaran/interview.blade.php ENDPATH**/ ?>