

<?php $__env->startSection('head'); ?>
<title>kerja jepang - Detail lowongan kerja</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="position-relative pb-1 pt-5">
    <div class="position-absolute top-0 start-0 end-0 alert-primary" style="height: 65%;z-index: -1;"></div>
    <div class="container mt-5">
        <div class="d-block bg-white rounded shadow p-4">
            <div class="row gy-4 align-items-center">
                <div class="col-12 col-md-9">
                        <p class="fs-4 fw-bold text-orange"><?php echo e($data->title); ?></p>
                        <p class="mb-1">Lokasi, <?php echo e($data->locations); ?></p>
                        <p class="mb-0 text-secondary">Postingan, <?php echo e(date('d F Y', strtotime($data->date_start))); ?></p>
                </div>
                <div class="col-12 col-md-3">
                    <?php if(auth()->guard('user')->check()): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pages.loker.submit', ['post' => $data])->html();
} elseif ($_instance->childHasBeenRendered('ZwqJ66m')) {
    $componentId = $_instance->getRenderedChildComponentId('ZwqJ66m');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZwqJ66m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZwqJ66m');
} else {
    $response = \Livewire\Livewire::mount('pages.loker.submit', ['post' => $data]);
    $html = $response->html();
    $_instance->logRenderedChild('ZwqJ66m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php else: ?>
                    <div class="d-grid gap-2">
                        <a class="btn btn-primary px-5" href="<?php echo e(route('login')); ?>">Apply Now</a>
                        <a class="btn btn-outline-primary px-5" href="<?php echo e(route('login')); ?>">
                            <i class="fas fa-star fa-sm fa-fw"></i> Simpan
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="py-3">
    <div class="container mb-3">
        <div class="row">
            <div class="col-12 col-md-9">
                <div class="d-block bg-white rounded shadow p-4">
                    <img src="<?php echo e(url('/images/loker/' . $data->images)); ?>" alt="logo" width="100%" class="rounded mb-3">
                    <div class="mb-5">
                        <?php echo $data->content ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/pages/loker/detail.blade.php ENDPATH**/ ?>