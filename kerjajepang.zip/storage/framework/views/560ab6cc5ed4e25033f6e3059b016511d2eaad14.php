<div>
    <div class="d-flex mb-3">
        <div class="ms-auto">
            <input wire:model='search' type="text" class="form-control" placeholder="Cari Transaksi...">
        </div>
    </div>
    <div class="d-block mb-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex align-items-center border rounded p-2 mb-2">
            <?php if($item->avatar == 'sample-avatar.png'): ?>
            <img src="<?php echo e(url('/images/avatar/' . $item->avatar )); ?>" class="rounded-circle" width="58px" height="58px">
            <?php else: ?>
            <img src="<?php echo e(url('/images/avatar/user/' . $item->avatar )); ?>" class="rounded-circle" width="58px"
                height="58px">
            <?php endif; ?>
            <div class="ms-3">
                <p class="fw-bold mb-0">
                    <?php echo e($item->username); ?>

                </p>
                <span>
                    <?php echo e($item->email); ?>

                </span>
            </div>
            <ul class="nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="fas fa-envelope fa-sm fa-fw"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="fas fa-globe fs-sm fa-fw"></i>
                    </a>
                </li>
            </ul>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="d-flex align-items-center">
        <p class="mb-0 border py-1 px-2 rounded">
            <span class="fw-bold"><?php echo e($data->count()); ?></span>
        </p>
        <?php if($data->hasPages()): ?>
        <nav class="ms-auto">
            <?php echo e($data->links('livewire.admin.users.paginations')); ?>

        </nav>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/admin/users/data.blade.php ENDPATH**/ ?>