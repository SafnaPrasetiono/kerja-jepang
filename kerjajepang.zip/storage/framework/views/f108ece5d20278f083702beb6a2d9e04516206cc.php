

<?php $__env->startSection('head'); ?>
<title>kerja jepang - Lamaran Saya</title>
<style>
    .link-tabs {
        text-align: start !important;
        color: #808080 !important;
        padding-top: 0.8rem !important;
        padding-bottom: 0.8rem !important;
        transition: all 0.3s !important;
        border-radius: 0px !important;
    }

    .link-tabs:hover {
        background: transparent !important;
        color: #0d6dfd9c !important;
        border-right: 4px solid #0d6dfd9c !important;
    }

    .link-tabs.active {
        background: transparent !important;
        color: #0d6efd !important;
        border-right: 4px solid #0d6efd !important;
    }

    .img-loker {
        width: 240px;
    }

    .tab-pane {
        min-height: 360px;
    }

    @media(max-width: 990px) {
        .img-loker {
            width: 100%;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="mt-5 pb-4 pt-5">
    <div class="container">
        <div class="d-block rounded shadow bg-white p-3 mb-3">
            <h3 class="fw-bold">Lamaran Saya</h3>
        </div>

        <div class="row">

            <div class="col-12 col-lg-3">
                <div class="d-block rounded shadow bg-white py-3">
                    <div class="nav flex-column nav-pills">
                        <button class="nav-link link-tabs active" data-bs-toggle="pill"
                            data-bs-target="#semua">Semua</button>
                        <button class="nav-link link-tabs" data-bs-toggle="pill"
                            data-bs-target="#pending">Proses</button>
                        <button class="nav-link link-tabs" data-bs-toggle="pill" data-bs-target="#review">Dalam
                            Review</button>
                        <button class="nav-link link-tabs" data-bs-toggle="pill"
                            data-bs-target="#interview">Interview</button>
                        <button class="nav-link link-tabs" data-bs-toggle="pill"
                            data-bs-target="#penawaran">Ditawarkan</button>
                        <button class="nav-link link-tabs" data-bs-toggle="pill"
                            data-bs-target="#terima">Diterima</button>
                        <button class="nav-link link-tabs" data-bs-toggle="pill" data-bs-target="#tidak-cocok">Tidak
                            Cocok</button>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-9">
                <div class="tab-content d-block bg-white rounded shadow p-3" id="v-pills-tabContent">
                    <div class="tab-pane fade show active" id="semua">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.lamaran.all')->html();
} elseif ($_instance->childHasBeenRendered('vC5764g')) {
    $componentId = $_instance->getRenderedChildComponentId('vC5764g');
    $componentTag = $_instance->getRenderedChildComponentTagName('vC5764g');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vC5764g');
} else {
    $response = \Livewire\Livewire::mount('user.lamaran.all');
    $html = $response->html();
    $_instance->logRenderedChild('vC5764g', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="tab-pane fade" id="pending">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.lamaran.proses')->html();
} elseif ($_instance->childHasBeenRendered('nsEnAh3')) {
    $componentId = $_instance->getRenderedChildComponentId('nsEnAh3');
    $componentTag = $_instance->getRenderedChildComponentTagName('nsEnAh3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nsEnAh3');
} else {
    $response = \Livewire\Livewire::mount('user.lamaran.proses');
    $html = $response->html();
    $_instance->logRenderedChild('nsEnAh3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="tab-pane fade" id="review">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.lamaran.review')->html();
} elseif ($_instance->childHasBeenRendered('nCPguHS')) {
    $componentId = $_instance->getRenderedChildComponentId('nCPguHS');
    $componentTag = $_instance->getRenderedChildComponentTagName('nCPguHS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nCPguHS');
} else {
    $response = \Livewire\Livewire::mount('user.lamaran.review');
    $html = $response->html();
    $_instance->logRenderedChild('nCPguHS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="tab-pane fade" id="interview">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.lamaran.interview')->html();
} elseif ($_instance->childHasBeenRendered('xagkdSO')) {
    $componentId = $_instance->getRenderedChildComponentId('xagkdSO');
    $componentTag = $_instance->getRenderedChildComponentTagName('xagkdSO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xagkdSO');
} else {
    $response = \Livewire\Livewire::mount('user.lamaran.interview');
    $html = $response->html();
    $_instance->logRenderedChild('xagkdSO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="tab-pane fade" id="penawaran">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore assumenda alias ducimus placeat
                        vero suscipit eveniet magni veniam eligendi! Ipsam ab consectetur eius dignissimos suscipit
                        natus culpa est laudantium cum?
                    </div>
                    <div class="tab-pane fade" id="terima">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.lamaran.accepted')->html();
} elseif ($_instance->childHasBeenRendered('e0GchSE')) {
    $componentId = $_instance->getRenderedChildComponentId('e0GchSE');
    $componentTag = $_instance->getRenderedChildComponentTagName('e0GchSE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('e0GchSE');
} else {
    $response = \Livewire\Livewire::mount('user.lamaran.accepted');
    $html = $response->html();
    $_instance->logRenderedChild('e0GchSE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <div class="tab-pane fade" id="tidak-cocok">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.lamaran.rejected')->html();
} elseif ($_instance->childHasBeenRendered('NMrDidz')) {
    $componentId = $_instance->getRenderedChildComponentId('NMrDidz');
    $componentTag = $_instance->getRenderedChildComponentTagName('NMrDidz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NMrDidz');
} else {
    $response = \Livewire\Livewire::mount('user.lamaran.rejected');
    $html = $response->html();
    $_instance->logRenderedChild('NMrDidz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/user/lamaran.blade.php ENDPATH**/ ?>