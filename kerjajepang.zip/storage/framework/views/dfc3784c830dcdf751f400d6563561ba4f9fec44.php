

<?php $__env->startSection('head'); ?>
<title>kerjajepang - data magang kerja</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="container-fluid">
    <div class="d-block rounded bg-white shadow">
        <div class="p-3 border-bottom">
            <p class="fs-4 fw-bold mb-0">Pertanyaan dan Jawaban</p>
        </div>
        <div class="d-block p-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.qa.index')->html();
} elseif ($_instance->childHasBeenRendered('uKQFyNf')) {
    $componentId = $_instance->getRenderedChildComponentId('uKQFyNf');
    $componentTag = $_instance->getRenderedChildComponentTagName('uKQFyNf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uKQFyNf');
} else {
    $response = \Livewire\Livewire::mount('admin.qa.index');
    $html = $response->html();
    $_instance->logRenderedChild('uKQFyNf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/qa/index.blade.php ENDPATH**/ ?>