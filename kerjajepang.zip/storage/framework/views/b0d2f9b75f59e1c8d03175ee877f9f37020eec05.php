

<?php $__env->startSection('head'); ?>
    <title>kerjajepang - Peraturan pages</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
    <div class="container-fluid">
        <div class="row gy-3">
            <div class="col-12">
                <div class="d-block bg-white rounded shadow p-3">
                    <p class="fs-4 fw-bold mb-0">Pages Settings</p>
                </div>
            </div>
            <div class="col-12">
                <div class="d-block bg-white rounded shadow p-3">
                    <table class="table table-borderless">
                        <thead class="alert-primary ">
                            <tr>
                                <th>No</th>
                                <th>Pages Name</th>
                                
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td scope="row">1</td>
                                <td>Home pages</td>
                                <td>
                                    <a href="<?php echo e(route('admin.pages.beranda')); ?>" class="btn btn-outline-primary btn-sm py-1">
                                        <i class="fas fa-edit fa-sm fa-fw"></i> Edit
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>