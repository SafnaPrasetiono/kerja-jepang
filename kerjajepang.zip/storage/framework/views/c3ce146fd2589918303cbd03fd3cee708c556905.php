

<?php $__env->startSection('head'); ?>
    <title>kerjajepang - training data</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
    <div class="container-fluid">
        <div class="row gy-4">
            <div class="col-12">
                <div class="d-block rounded bg-white shadow p-3">
                    <p class="fs-4 fw-bold mb-0">Training Pages</p>
                </div>
            </div>
            <div class="col-12">
                <div class="d-block rounded bg-white shadow p-3">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.training.data')->html();
} elseif ($_instance->childHasBeenRendered('P8BBXxH')) {
    $componentId = $_instance->getRenderedChildComponentId('P8BBXxH');
    $componentTag = $_instance->getRenderedChildComponentTagName('P8BBXxH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('P8BBXxH');
} else {
    $response = \Livewire\Livewire::mount('admin.training.data');
    $html = $response->html();
    $_instance->logRenderedChild('P8BBXxH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/training/index.blade.php ENDPATH**/ ?>