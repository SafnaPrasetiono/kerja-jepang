<div>
    <div class="pt-5 pb-4">
        <div class="container">
            <div class="d-flex align-items-center mb-4">
                <div>
                    <h4 class="fw-bold">Bursa kerja Terbaru</h4>
                    <p class="mb-0 text-secondary">Yuk, cari pekerjaan yang sesuai dengan kamu</p>
                </div>
                <a href="#" class="btn btn-outline-primary rounded-pill py-1 ms-auto">Semua <i
                        class="fas fa-angle-right fa-sm fa-fw"></i></a>
            </div>
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card">
                        
                        <div class="card-body">
                            <a href="<?php echo e(route('loker.detail', ['slug' => $item->slug])); ?>" class="card-title fs-5 fw-bold text-ellipsis-2 text-decoration-none mb-1">
                                <?php echo e($item->title); ?>

                            </a>
                            <small class="d-block text-secondary mb-3">Posting, <?php echo e(date('d F Y', strtotime($item->date_start))); ?> - <?php echo e(date('d F Y', strtotime($item->date_end))); ?></small>
                            <p class="card-text text-ellipsis-3"><?php echo e($item->description); ?></p>
                            <a href="<?php echo e(route('loker.detail', ['slug' => $item->slug])); ?>" class="btn link-primary px-0">Lihat detail <i class="fas fa-arrow-right fa-sm fa-fw"></i> </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/pages/index/loker.blade.php ENDPATH**/ ?>