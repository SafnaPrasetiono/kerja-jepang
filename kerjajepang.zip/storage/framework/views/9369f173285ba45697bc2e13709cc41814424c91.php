

<?php $__env->startSection('head'); ?>
<title>kerjajepang - data magang kerja</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="container-fluid">
    <div class="d-block rounded bg-white shadow">
        <div class="p-3 border-bottom">
            <p class="fs-4 fw-bold mb-0">Page Ex.Magang</p>
        </div>
        <div class="d-block p-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.magang.data')->html();
} elseif ($_instance->childHasBeenRendered('wjAmRnE')) {
    $componentId = $_instance->getRenderedChildComponentId('wjAmRnE');
    $componentTag = $_instance->getRenderedChildComponentTagName('wjAmRnE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wjAmRnE');
} else {
    $response = \Livewire\Livewire::mount('admin.magang.data');
    $html = $response->html();
    $_instance->logRenderedChild('wjAmRnE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/magang/data.blade.php ENDPATH**/ ?>