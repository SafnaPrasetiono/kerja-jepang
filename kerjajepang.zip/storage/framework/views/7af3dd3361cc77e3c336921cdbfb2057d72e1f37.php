

<?php $__env->startSection('head'); ?>
<title>kerjajepang - admin profile</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="mb-3">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.profile.data')->html();
} elseif ($_instance->childHasBeenRendered('NFETre6')) {
    $componentId = $_instance->getRenderedChildComponentId('NFETre6');
    $componentTag = $_instance->getRenderedChildComponentTagName('NFETre6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NFETre6');
} else {
    $response = \Livewire\Livewire::mount('admin.profile.data');
    $html = $response->html();
    $_instance->logRenderedChild('NFETre6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<div class="mb-3">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.profile.password')->html();
} elseif ($_instance->childHasBeenRendered('ib2VgnQ')) {
    $componentId = $_instance->getRenderedChildComponentId('ib2VgnQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('ib2VgnQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ib2VgnQ');
} else {
    $response = \Livewire\Livewire::mount('admin.profile.password');
    $html = $response->html();
    $_instance->logRenderedChild('ib2VgnQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/profile/index.blade.php ENDPATH**/ ?>