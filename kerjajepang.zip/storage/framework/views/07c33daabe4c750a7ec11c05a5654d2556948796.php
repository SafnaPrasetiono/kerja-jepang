<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo e(url('/')); ?>/beranda</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>1.0</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/prosedur</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/beranda/pemula</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/beranda/berita</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/pelatihan</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/galeri</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/qa</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/tentang-kami</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>0.8</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/register</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>1.0</priority>
    </url>
    <url>
        <loc><?php echo e(url('/')); ?>/login</loc>
        <lastmod>2022-04-22T09:48:37+01:00</lastmod>
        <priority>1.0</priority>
    </url>
    <?php $__currentLoopData = $loker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lkr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <url>
        <loc><?php echo e(url('/')); ?>/beranda/loker/<?php echo e($lkr->slug); ?></loc>
        <lastmod><?php echo e($lkr->created_at->tz('UTC')->toAtomString()); ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>0.6</priority>
    </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $magang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <url>
        <loc><?php echo e(url('/')); ?>/beranda/magang/<?php echo e($mg->slug); ?></loc>
        <lastmod><?php echo e($mg->created_at->tz('UTC')->toAtomString()); ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>0.6</priority>
    </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <url>
        <loc><?php echo e(url('/')); ?>/beranda/berita/<?php echo e($row->slug); ?>+<?php echo e($row->id_news); ?></loc>
        <lastmod><?php echo e($row->created_at->tz('UTC')->toAtomString()); ?></lastmod>
        <changefreq>daily</changefreq>
        <priority>0.6</priority>
    </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/sitemap.blade.php ENDPATH**/ ?>