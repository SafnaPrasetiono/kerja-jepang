

<?php $__env->startSection('head'); ?>
    <title>kerjajepang - Edit Beranda pages</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
    <div class="container-fluid">
        <div class="d-block rounded bg-white shadow">
            <div class="p-3 border-bottom">
                <p class="fs-4 fw-bold mb-0">Beranda</p>
            </div>
            <div class="p-3">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.pages.branda.banner')->html();
} elseif ($_instance->childHasBeenRendered('kkpbYeS')) {
    $componentId = $_instance->getRenderedChildComponentId('kkpbYeS');
    $componentTag = $_instance->getRenderedChildComponentTagName('kkpbYeS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kkpbYeS');
} else {
    $response = \Livewire\Livewire::mount('admin.pages.branda.banner');
    $html = $response->html();
    $_instance->logRenderedChild('kkpbYeS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/pages/beranda.blade.php ENDPATH**/ ?>