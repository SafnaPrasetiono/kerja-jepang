<div>
    <div class="py-3">
        <div class="d-flex">
            <div class="" style="width: 300px;">
                <input wire:model='search' type="text" class="form-control" placeholder="Cari...">
            </div>
        </div>
    </div>
    <div class="py-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-3">
            <button class="btn w-100 text-start border rounded-0 py-3 mb-0" type="button" data-bs-toggle="collapse"
                data-bs-target="#collapseExample-<?php echo e($index); ?>">
                <?php echo $item->question ?>
            </button>
            <div class="collapse" id="collapseExample-<?php echo e($index); ?>">
                <div class="py-3 px-2">
                    <?php echo $item->answer ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="py-4">
        <div class="d-flex align-items-center">
            <?php if($data->hasPages()): ?>
            <nav class="ms-auto">
                <?php echo e($data->links('livewire.admin.qa.paginations')); ?>

            </nav>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/pages/qa/data.blade.php ENDPATH**/ ?>