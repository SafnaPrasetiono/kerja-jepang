

<?php $__env->startSection('head'); ?>
<title>kerja jepang - Pelatihan untuk kerja dijepang</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="position-relative pt-5">
    <div class="position-absolute top-0 start-0 end-0 alert-primary" style="height: 65%;z-index: -1;"></div>
    <div class="container pt-5 pb-2">
        <div class="d-block rounded bg-white py-4 px-3">
                <p class="fs-3 fw-bold text-orange mb-0">PELATIHAN KERJA JEPANG</p>
                <p class="mb-0">Cari pelatihan untuk bekerja dijepang</p>
        </div>
    </div>
</div>
<div class="pt-3 pb-4">
    <div class="container">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pages.training.data')->html();
} elseif ($_instance->childHasBeenRendered('gcty51y')) {
    $componentId = $_instance->getRenderedChildComponentId('gcty51y');
    $componentTag = $_instance->getRenderedChildComponentTagName('gcty51y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gcty51y');
} else {
    $response = \Livewire\Livewire::mount('pages.training.data');
    $html = $response->html();
    $_instance->logRenderedChild('gcty51y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/pages/training.blade.php ENDPATH**/ ?>