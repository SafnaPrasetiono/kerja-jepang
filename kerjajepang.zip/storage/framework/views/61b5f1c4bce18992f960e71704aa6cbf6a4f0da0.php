

<?php $__env->startSection('head'); ?>
    <title>kerjajepang - selamat datang di admin kerja jepang</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="container-fluid">
    <div class="row g-2 mb-3">
        <div class="col-12">
            <div class="d-block bg-white rounded shadow p-3">
                <h3 class="fw-bold text-capitalize">Hello, <?php echo e(auth('admin')->user()->username); ?></h3>
                <p class="mb-0 text-secondary">Selamat Datang di Dashboard Kerja Jepang</p>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                    <i class="fas fa-briefcase fa-3x py-auto "></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($loker); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white px-1">
                    <small class="text-start fw-bold">Bursa Kerja</small>
                </div>
                <a href="<?php echo e(route('admin.loker')); ?>" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                    <i class="fas fa-business-time fa-3x fa-fw"></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($magang); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white">
                    <small class="text-start fw-bold">Ex. Magang</small>
                </div>
                <a href="<?php echo e(route('admin.magang')); ?>" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                    <i class="fas fa-money-check-alt fa-3x"></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($news); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white px-1">
                    <small class="text-start fw-bold">Berita</small>
                </div>
                <a href="<?php echo e(route('admin.news')); ?>" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                    <i class="fas fa-images fa-3x fa-fw"></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($galery); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white px-1">
                    <small class="text-start fw-bold">Galery</small>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                    <i class="fas fa-info-square fa-3x fa-fw"></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($qa); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white px-1">
                    <small class="text-start fw-bold">Q&A</small>
                </div>
                <a href="<?php echo e(route('admin.qa')); ?>" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                    <i class="fas fa-backpack fa-3x fa-fw"></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($comer); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white px-1">
                    <small class="text-start fw-bold">Karantina</small>
                </div>
                <a href="<?php echo e(route('admin.karantina')); ?>" class="stretched-link"></a>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                   <i class="fas fa-user fa-3x fa-fw"></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($admin); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white px-1">
                    <small class="text-start fw-bold">Admin</small>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-6 col-lg-3">
            <div class="card p-2 shadow">
                <div class="d-flex align-items-center px-2">
                    <i class="fas fa-users fa-3x fa-fw"></i>
                    <div class="card-body text-end">
                        <p class="card-title fs-2 mb-0"><?php echo e($user); ?></p>
                    </div>
                </div>
                <div class="card-footer bg-white px-1">
                    <small class="text-start fw-bold">User</small>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/index.blade.php ENDPATH**/ ?>