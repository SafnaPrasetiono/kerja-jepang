<div>
    <div class="d-block bg-white rounded shadow mb-3">
        <div class="p-3 border-bottom">
            <p class="mb-0 fw-bold">Akun Kamu</p>
        </div>
        <div class="px-3 pt-4 pb-5">
            <label for="" class="form-label mb-3">Kamu dapat masuk melalui salah satu akun di bawah ini:</label>
            <div class="mb-3">
                <p class="fs-5 fw-bold mb-0"><?php echo e(auth('user')->user()->username); ?></p>
            <p class="fs-5 mb-0"><?php echo e(auth('user')->user()->email); ?></p>
            </div>
                <p class="mb-0">Status Akun : <span class="badge bg-primary">Active</span></p>
        </div>
    </div>
    <div class="d-block bg-white rounded shadow mb-3">
        <div class="d-flex align-items-center p-3">
            <div class="p-3" style="width: 270px">
                <img src="<?php echo e(url('/images/banner/password.png')); ?>" alt="" class="img-fluid">
            </div>
            <div class="ms-0 ms-md-4">
                <p class="fs-5 fw-bold">Rubah Password Akun Kamu</p>
                <p class="text-secondary mb-0">Akun Kamu</p>
                <p class="mb-4"><?php echo e(auth('admin')->user()->email); ?></p>
                <button wire:click='show' type="button" class="btn btn-outline-primary rounded-0">Ubah Password</button>
            </div>
        </div>
    </div>

    <div wire:ignore.self class="modal fade" id="passwordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="mb-3 text-center py-3">
                        <img src="<?php echo e(url('/images/banner/password.png')); ?>" alt="" class="img-fluid w-50 mb-3">
                        <p class="fs-4 fw-bold">Rubah Password</p>
                    </div>
                    <div class="mb-3">
                        <label for="question" class="form-label">Password</label>
                        <input wire:model='password' type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="answer" class="form-label">Confirmasi password</label>
                        <input wire:model='confirmation' type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-check">
                        <input wire:model='cek' class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                          Rubah Password Saya
                        </label>
                      </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button wire:click='setup' type="button" class="btn btn-primary" <?php if($cek != true): ?> disabled <?php endif; ?>>Simpan</button>
                  </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(url('/dist/style/js/jquery.js')); ?>"></script>
    <script>
        document.addEventListener('pModalShow', () => {
            $('#passwordModal').modal('show');
        });
        document.addEventListener('pModalExpand', () => {
            $('#passwordModal').modal('hide');
        });
        document.addEventListener('deleteConfrimed', function() {
            Swal.fire({
                    title: "Delete?",
                    text: "Are you sure to delete this q&a?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Tidak',
                })
                .then((next) => {
                    if (next.isConfirmed) {
                        Livewire.emit('deleteAction');
                    } else {
                        Swal.fire("Data anda tetap aman!");
                    }
                });
        })
    </script>

    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Good Jobs!',
            text: '<?php echo e(session()->get("success")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
        location.reload();
    </script>
    <?php elseif(session()->has('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Opps...!',
            text: '<?php echo e(session()->get("error")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
    </script>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/user/setting/account.blade.php ENDPATH**/ ?>