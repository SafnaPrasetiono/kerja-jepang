<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->yieldContent('head'); ?>
    <link rel="stylesheet" href="<?php echo e(url('/dist/app/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/dist/icons/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/dist/style/css/auth/auth.css')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>

    <?php echo $__env->yieldContent('pages'); ?>

    <script src="<?php echo e(url('/dist/style/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(url('/dist/style/js/popper.js')); ?>"></script>
    <script src="<?php echo e(url('/dist/app/js/app.js')); ?>"></script>
    <script src="<?php echo e(url('/dist/style/js/alert.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>


    <?php echo $__env->yieldContent('script'); ?>

    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Good Jobs!',
            text: '<?php echo e(session()->get("success")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
    </script>
    <?php elseif(session()->has('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Opps...!',
            text: '<?php echo e(session()->get("error")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
    </script>
    <?php endif; ?>

</body>

</html><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/auth/layouts/panel.blade.php ENDPATH**/ ?>