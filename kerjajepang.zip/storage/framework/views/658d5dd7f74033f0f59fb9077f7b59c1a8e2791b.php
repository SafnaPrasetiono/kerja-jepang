<div>
    <div class="d-flex mb-3">
        <a href="<?php echo e(route('admin.qa.create')); ?>" class="btn btn-outline-secondary">Tambah</a>
        
        <div class="ms-auto">
            <input wire:model='search' type="text" class="form-control" placeholder="Cari Transaksi...">
        </div>
    </div>
    <div class="d-block">
        <table class="table table-borderless">
            <thead class="alert-secondary">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Pertanyaan</th>
                    
                    <th scope="col">Date</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($index + 1); ?></th>
                    <td><?php echo $item->question ?></td>
                    
                    <td>
                        <?php echo e(date("d F Y", strtotime($item->created_at))); ?>

                    </td>
                    <td>
                        <button wire:click='show(<?php echo e($item->id_qa); ?>)' type="button"
                            class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-eye fa-sm fa-fw"></i>
                        </button>
                        <a href="<?php echo e(route('admin.qa.edit', ['id' => $item->id_qa])); ?>" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-pencil-alt fa-sm fa-fw"></i>
                        </a>
                        <button wire:click="removed(<?php echo e($item->id_qa); ?>)" type="button"
                            class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-trash fa-sm fa-fw"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex align-items-center">
        <p class="mb-0 border py-1 px-2 rounded">
            <span class="fw-bold"><?php echo e($data->count()); ?></span>
        </p>
        <?php if($data->hasPages()): ?>
        <nav class="ms-auto">
            <?php echo e($data->links('livewire.admin.qa.paginations')); ?>

        </nav>
        <?php endif; ?>
    </div>


    <div wire:ignore.self class="modal fade" id="MyModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <?php if($edit == false): ?>
                        <span>Create Q&A</span>
                        <?php else: ?>
                        <span>Edit Q&A</span>
                        <?php endif; ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="question" class="form-label">Pertanyaan</label>
                        <div class="alert alert-secondary"><?php echo $question ?></div>
                    </div>
                    <div class="mb-3">
                        <label for="answer" class="form-label">Jawaban</label>
                        <div class="alert alert-secondary">
                            <?php echo $answer ?>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="about" class="form-label">Topik Pembahasan</label>
                        <div class="alert alert-secondary">
                            <?php echo $about ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="<?php echo e(url('/dist/style/js/jquery.js')); ?>"></script>
    <script>
        document.addEventListener('ModalShow', () => {
            $('#MyModal').modal('show');
        });
        document.addEventListener('ModalExpand', () => {
            $('#MyModal').modal('hide');
        });
        document.addEventListener('deleteConfrimed', function() {
            Swal.fire({
                    title: "Delete?",
                    text: "Are you sure to delete this q&a?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Tidak',
                })
                .then((next) => {
                    if (next.isConfirmed) {
                        Livewire.emit('deleteAction');
                    } else {
                        Swal.fire("Data anda tetap aman!");
                    }
                });
        })
    </script>

    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Good Jobs!',
            text: '<?php echo e(session()->get("success")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
        location.reload();
    </script>
    <?php elseif(session()->has('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Opps...!',
            text: '<?php echo e(session()->get("error")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
    </script>
    <?php endif; ?>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/admin/qa/index.blade.php ENDPATH**/ ?>