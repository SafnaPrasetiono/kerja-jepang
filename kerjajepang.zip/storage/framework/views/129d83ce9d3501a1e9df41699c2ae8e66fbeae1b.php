

<?php $__env->startSection('head'); ?>
<title>kerjajepang - question and answer</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div style="height: 60px;" class="d-block w-100"></div>
<div class="position-relative pb-3 pt-5 mb-3">
    <div class="position-absolute top-0 start-0 end-0 alert-primary" style="height: 60%;z-index: -1;"></div>
    <div class="container">
        <div class="d-block rounded bg-white py-4 px-3">
            <p class="fs-3 fw-bold text-orange mb-0">Pertanyaan Seputar Kerja Jepang</p>
            <p class="mb-0">Kurang informasi yuk, cari informasi disini</p>
        </div>
    </div>
</div>
<div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pages.qa.data')->html();
} elseif ($_instance->childHasBeenRendered('s8XVSfg')) {
    $componentId = $_instance->getRenderedChildComponentId('s8XVSfg');
    $componentTag = $_instance->getRenderedChildComponentTagName('s8XVSfg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('s8XVSfg');
} else {
    $response = \Livewire\Livewire::mount('pages.qa.data');
    $html = $response->html();
    $_instance->logRenderedChild('s8XVSfg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/pages/qa.blade.php ENDPATH**/ ?>