

<?php $__env->startSection('head'); ?>
<title>kerjajepang - pelamar dari lowongan kerja</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="container-fluid">
    <div class="d-block rounded bg-white shadow">
        <div class="p-3 border-bottom">
            <p class="fs-4 fw-bold mb-0">Pelamar Pekerjaan</p>
        </div>
        <div class="d-block p-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.proposal.data')->html();
} elseif ($_instance->childHasBeenRendered('2L6lJXz')) {
    $componentId = $_instance->getRenderedChildComponentId('2L6lJXz');
    $componentTag = $_instance->getRenderedChildComponentTagName('2L6lJXz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2L6lJXz');
} else {
    $response = \Livewire\Livewire::mount('admin.proposal.data');
    $html = $response->html();
    $_instance->logRenderedChild('2L6lJXz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/proposal/index.blade.php ENDPATH**/ ?>