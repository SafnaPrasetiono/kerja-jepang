

<?php $__env->startSection('head'); ?>
<title>kerja jepang - Daftar sebagai pemula baru</title>
<style>
    .foto-upload {
        position: relative;
        display: flex;
        width: 100%;
        min-height: 120px;
        border: 1px dashed #0007;
        align-items: center;
        justify-content: center;
    }

    .loading-stage {
        position: absolute;
        width: 100%;
        height: 100%;
        align-items: center;
        justify-content: center;
        background-color: #0004;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="d-block" style="height: 60px;"></div>
<div class="py-4">
    <div class="container">
        <form action="<?php echo e(route('index.comer.register.post')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pages.comer.biodata')->html();
} elseif ($_instance->childHasBeenRendered('E0GsrBC')) {
    $componentId = $_instance->getRenderedChildComponentId('E0GsrBC');
    $componentTag = $_instance->getRenderedChildComponentTagName('E0GsrBC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E0GsrBC');
} else {
    $response = \Livewire\Livewire::mount('pages.comer.biodata');
    $html = $response->html();
    $_instance->logRenderedChild('E0GsrBC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pages.comer.address')->html();
} elseif ($_instance->childHasBeenRendered('9q1tLTk')) {
    $componentId = $_instance->getRenderedChildComponentId('9q1tLTk');
    $componentTag = $_instance->getRenderedChildComponentTagName('9q1tLTk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9q1tLTk');
} else {
    $response = \Livewire\Livewire::mount('pages.comer.address');
    $html = $response->html();
    $_instance->logRenderedChild('9q1tLTk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pages.comer.documents')->html();
} elseif ($_instance->childHasBeenRendered('tQmMOuH')) {
    $componentId = $_instance->getRenderedChildComponentId('tQmMOuH');
    $componentTag = $_instance->getRenderedChildComponentTagName('tQmMOuH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tQmMOuH');
} else {
    $response = \Livewire\Livewire::mount('pages.comer.documents');
    $html = $response->html();
    $_instance->logRenderedChild('tQmMOuH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <div class="d-block rounded border mb-3">
                <div class="py-2 px-3 border-bottom">
                    <p class="mb-0 fw-bold">Syarat Ketentuan</p>
                </div>
                <div class="p-3">
                    <div class="alert alert-info d-flex align-items-center mb-3">
                        <i class="fas fa-info-circle fa-fw"></i>
                        <p class="mb-0 fw-bold ms-2">Bacalah secara saksama dan jelas agar data kamu lolos dan cepat
                            diproses oleh pihak kami.</p>
                    </div>
                    <div>
                        <p class="fw-bold mb-2">
                            Persyaratan Account
                        </p>
                        <ul>
                            <li>Akun email kamu harus aktif agar pihak kami mudah untuk memberikan informasi</li>
                        </ul>
                    </div>
                    <div>
                        <p class="fw-bold mb-2">
                            Peraturan Biodata dan alamat
                        </p>
                        <ul>
                            <li>Biodata yang kamu inputkan harus sesuai dengan informasi mengenai dirikamu kamu</li>
                            <li>Nomor telepon harus aktif dan sudah terintegrasi dengan whatsapp</li>
                            <li>Alamat harus sesuai dengan domisili diri kamu atau sesuai dengan kediamanmu saat ini
                            </li>
                            <li>Pastikan semua input biodata dan alamat harus terisi semua</li>
                        </ul>
                    </div>
                    <div>
                        <p class="fw-bold mb-2">
                            Peraturan Upload Document
                        </p>
                        <ul>
                            <li>Kamu harus upload Kartu Tanda Penduduk(KTP)</li>
                            <li>Kamu harus upload Kartu Keluarga(KK) terbaru</li>
                            <li>Kamu harus upload akte kelahiran</li>
                            <li>Upload pas foto haru menggunakan pakaian resmi</li>
                            <li>Upload pas foto harus berukuran 4x6</li>
                            <li>Format upload semua document ber extensi png, jpg, jpeg atau mpeg</li>
                        </ul>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="cek1">
                        <label class="form-check-label cek" for="cek1">
                            Saya menerima persyaratan yang telah diberikan
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="cek2">
                        <label class="form-check-label cek" for="cek2">
                            Saya dalam kondisi sadar dan sehat melengkapi biodata pendaftaran
                        </label>
                    </div>
                </div>
            </div>
            <div class="d-block rounded border mb-3 p-4">
                <button class="btn btn-primary btn-lg w-100 disabled" id="btnSubmit">DAFTARKAN DIRI SAYA</button>
            </div>
        </form>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#cek1').change(function(){
            if($('#cek1').is(':checked')== true && $('#cek2').is(':checked') == true){
                if($('#btnSubmit').hasClass('disabled')){
                    $('#btnSubmit').removeClass('disabled');
                }
            } else {
                if(!$('#btnSubmit').addClass('disabled')){
                    $('#btnSubmit').addClass('disabled');
                }
            }
    });
    $('#cek2').change(function(){
            if($('#cek1').is(':checked')== true && $('#cek2').is(':checked') == true){
                if($('#btnSubmit').hasClass('disabled')){
                    $('#btnSubmit').removeClass('disabled');
                }
            } else{
                if(!$('#btnSubmit').addClass('disabled')){
                    $('#btnSubmit').addClass('disabled');
                }
            }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/pages/comer/registery.blade.php ENDPATH**/ ?>