

<?php $__env->startSection('head'); ?>
<title>kerja jepang - Detail lowongan kerja</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="position-relative pb-1 pt-5">
    <div class="position-absolute top-0 start-0 end-0 alert-primary" style="height: 65%;z-index: -1;"></div>
    <div class="container pt-5">
        <div class="row gy-4 rounded bg-white align-items-center py-4 px-3">
            <div class="col-12 col-md-9">
                <div class="px-3">
                    <img src="<?php echo e(url('/images/loker/' . $data->images)); ?>" alt="logo" width="92px" height="92px">
                    <p class="fs-4 fw-bold text-orange mb-0"><?php echo e($data->title); ?></p>
                    <p class="mb-0 fs-5 text-capitalize"><?php echo e($data->instansi); ?></p>
                    <p class="mb-2"><?php echo e($data->locations); ?></p>
                    <p class="mb-0 text-secondary"><?php echo e(date('d F Y', strtotime($data->date_start))); ?></p>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="d-grid gap-2">
                    <button class="btn btn-primary px-5" type="button">Apply Now</button>
                    <button class="btn btn-outline-primary px-5" type="button">Simpan</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="py-3">
    <div class="container mb-3">
        <div class="d-block bg-white rounded shadow p-4">
            <div class="mb-5">
                <?php echo $data->content ?>
            </div>
            <div class="row g-3">
                <div class="col-12">
                    <p class="fs-5 fw-bold mb-0">Informasi Tambahan</p>
                </div>
                <div class="col-12 col-md-6">
                    <label for="" class="fw-bold">Tingkatan Karir</label>
                    <p class="mb-0"><?php echo e($data->level); ?></p>
                </div>
                <div class="col-12 col-md-6">
                    <label for="" class="fw-bold">kualifikasi</label>
                    <p class="mb-0"><?php echo e($data->qualification); ?></p>
                </div>
                <div class="col-12 col-md-6">
                    <label for="" class="fw-bold">Tipe Pekerjaan</label>
                    <p class="mb-0"><?php echo e($data->job_type); ?></p>
                </div>
                <div class="col-12 col-md-6">
                    <label for="" class="fw-bold">Pengalaman</label>
                    <p class="mb-0"><?php echo e($data->experience); ?> Tahun</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="d-block bg-white rounded shadow p-4">
            <div class="mb-3">
                <?php echo $data->aboutinstansi ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/pages/lokerDetail.blade.php ENDPATH**/ ?>