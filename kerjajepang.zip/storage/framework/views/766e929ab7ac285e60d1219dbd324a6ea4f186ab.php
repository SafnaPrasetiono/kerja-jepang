<div>
    <div class="row g-3 align-items-center mb-4">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="my-columnt col-6 col-md-4 col-lg-3">
            <div wire:click='show(<?php echo e($item->id_galeries); ?>)' class="btn imgGalery"
                style="background-image: url('/images/galery/<?php echo e($item->images); ?>')"></div>
            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if($data->hasPages()): ?>
    <div class="d-flex justify-content-center">
        <?php echo e($data->links('layouts.paginations')); ?>

    </div>
    <?php endif; ?>


    <div class="modal fade" id="imgModals" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content position-relative">
                <button type="button" class="btn text-white position-absolute end-0 m-3" data-bs-dismiss="modal" aria-label="Close">
                    <i class="fas fa-times fa-lg fa-fw"></i>
                </button>
                <?php if($detailImg): ?>
                <img src="<?php echo e(url('/images/galery/' . $detailImg->images)); ?>" alt="" class="img-fluid rounded">
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('showModal', function() {
            $('#imgModals').modal('show');
        });
    </script>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/pages/galery/data.blade.php ENDPATH**/ ?>