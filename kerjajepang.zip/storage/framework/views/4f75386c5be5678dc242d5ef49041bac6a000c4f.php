

<?php $__env->startSection('head'); ?>
<title>kerjajepang - lowongan kerja</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="container-fluid">
    <div class="d-block bg-white rounded shadow p-3 mb-3">
        <div class="row">
            <div class="col-12 col-sm-5 col-md-4 col-lg-3">
                <img src="<?php echo e(url('/images/loker/'.$data->images)); ?>" alt="" class="img-fluid">
            </div>
            <div class="col-12 col-sm-7 col-md-8 col-lg-9">
                <div class="p-3 p-sm-0">
                    <p class="fs-5 fw-bold mb-2"><?php echo e($data->title); ?></p>
                    <p class="mb-0 text-secondary"><?php echo e(date('d F Y', strtotime($data->date_start))); ?> - <?php echo e(date('d F Y',
                        strtotime($data->date_end))); ?></p>
                    <p class="text-secondary mb-0"><?php echo e($data->locations); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="d-block bg-white rounded shadow mb-3">
        <div class="d-block p-3 border-bottom">
            <p class="fs-5 mb-0 fw-bold">Pelamar pekerjaan</p>
        </div>
        <div class="p-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.loker.pelamar', ['id' => $data->id_lokers])->html();
} elseif ($_instance->childHasBeenRendered('zMPH2za')) {
    $componentId = $_instance->getRenderedChildComponentId('zMPH2za');
    $componentTag = $_instance->getRenderedChildComponentTagName('zMPH2za');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zMPH2za');
} else {
    $response = \Livewire\Livewire::mount('admin.loker.pelamar', ['id' => $data->id_lokers]);
    $html = $response->html();
    $_instance->logRenderedChild('zMPH2za', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/loker/detail.blade.php ENDPATH**/ ?>