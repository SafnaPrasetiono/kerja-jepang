<div>
    <div class="d-flex mb-3">
        <a href="<?php echo e(route('admin.training.create')); ?>" class="btn btn-outline-secondary">Tambah</a>
        <div class="ms-auto">
            <input wire:model='search' type="text" class="form-control" placeholder="Cari Transaksi...">
        </div>
    </div>
    <div class="d-block">
        <table class="table table-borderless">
            <thead class="alert-secondary">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Images</th>
                    <th scope="col">Title</th>
                    <th scope="col">Date</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($index + 1); ?></th>
                    <td>
                        <img src="<?php echo e(url('/images/training/' . $item->images )); ?>" class="rounded" width="100px">
                    </td>
                    <td><?php echo e($item->title); ?></td>
                    <td>
                        <?php echo e(date("d F Y", strtotime($item->created_at))); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.training.edit', ['id' => $item->id_training])); ?>" class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-pencil-alt fa-sm fa-fw"></i>
                        </a>
                        <button wire:click="removed(<?php echo e($item->id_news); ?>)" type="button"
                            class="btn btn-outline-secondary btn-sm">
                            <i class="fas fa-trash fa-sm fa-fw"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex align-items-center">
        <p class="mb-0 border py-1 px-2 rounded">
            <span class="fw-bold"><?php echo e($data->count()); ?></span>
        </p>
        <?php if($data->hasPages()): ?>
        <nav class="ms-auto">
            <?php echo e($data->links('livewire.admin.news.paginations')); ?>

        </nav>
        <?php endif; ?>
    </div>


    <script>
        document.addEventListener('deleteConfrimed', function() {
            Swal.fire({
                    title: "Delete?",
                    text: "Are you sure to delete this product?",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete!',
                    cancelButtonText: 'Tidak',
                })
                .then((next) => {
                    if (next.isConfirmed) {
                        Livewire.emit('deleteAction');
                    } else {
                        Swal.fire("Your product is save!");
                    }
                });
        })
    </script>

    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Good Jobs!',
            text: '<?php echo e(session()->get("success")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
        location.reload();
    </script>
    <?php elseif(session()->has('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Opps...!',
            text: '<?php echo e(session()->get("error")); ?>',
            showConfirmButton: false,
            timer: 2500
        })
    </script>
    <?php endif; ?>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/admin/training/data.blade.php ENDPATH**/ ?>