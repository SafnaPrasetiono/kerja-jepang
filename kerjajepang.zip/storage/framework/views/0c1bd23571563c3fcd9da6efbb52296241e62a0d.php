

<?php $__env->startSection('head'); ?>
<title>kerjajepang - lowongan kerja</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="container-fluid">
    <div class="d-block rounded bg-white shadow">
        <div class="p-3 border-bottom">
            <p class="fs-4 fw-bold mb-0">page lowongan kerja</p>
        </div>
        <div class="d-block p-3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.loker.data')->html();
} elseif ($_instance->childHasBeenRendered('jt13FsW')) {
    $componentId = $_instance->getRenderedChildComponentId('jt13FsW');
    $componentTag = $_instance->getRenderedChildComponentTagName('jt13FsW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jt13FsW');
} else {
    $response = \Livewire\Livewire::mount('admin.loker.data');
    $html = $response->html();
    $_instance->logRenderedChild('jt13FsW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/loker/data.blade.php ENDPATH**/ ?>