

<?php $__env->startSection('head'); ?>
    <title>kerjajepang - data users</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
    <div class="container-fluid">
        <div class="row gy-4">
            <div class="col-12">
                <div class="d-block rounded bg-white shadow p-3">
                    <p class="fs-4 fw-bold mb-0">Data User</p>
                </div>
            </div>
            <div class="col-12">
                <div class="d-block rounded bg-white shadow p-3">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users.data')->html();
} elseif ($_instance->childHasBeenRendered('PfykxGi')) {
    $componentId = $_instance->getRenderedChildComponentId('PfykxGi');
    $componentTag = $_instance->getRenderedChildComponentTagName('PfykxGi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PfykxGi');
} else {
    $response = \Livewire\Livewire::mount('admin.users.data');
    $html = $response->html();
    $_instance->logRenderedChild('PfykxGi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/admin/users/data.blade.php ENDPATH**/ ?>