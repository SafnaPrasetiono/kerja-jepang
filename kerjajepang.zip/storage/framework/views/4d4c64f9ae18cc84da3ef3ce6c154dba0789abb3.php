

<?php $__env->startSection('head'); ?>
    <title>kerjajepang - reset password akun</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
    <div class="box-auth">
        <div class="box-head text-center">
            <img src="<?php echo e(url('/images/banner/password.png')); ?>" alt="" width="70%" class="mb-4">
            <h3 class="text-orange fw-bold">LUPA PASSWORD</h3>
            <p class="mb-0">Tidak perlu khawatir, akun kamu tetap aman <br> Rubah password dan amankan akun kamu</p>
        </div>
        <div class="box-body pb-4">
            <form method="POST" action="<?php echo e(route('password.post')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    
                    <input name="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Email" placeholder="Email Address">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary form-control">UBAH PASSWORD</button>
            </form>
        </div>
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/auth/password.blade.php ENDPATH**/ ?>