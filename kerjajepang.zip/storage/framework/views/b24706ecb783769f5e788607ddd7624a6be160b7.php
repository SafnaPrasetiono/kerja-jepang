<div>
    <div class="d-grid gap-2">
        <?php if($proposal): ?>
        <button class="btn btn-primary px-5 disabled" type="button" disabled>Apply Now</button>
        <?php else: ?>
        <button wire:click='show' class="btn btn-primary px-5" type="button">Apply Now</button>
        <?php endif; ?>
        <?php if($wishlist): ?>    
        <button wire:click='unlove(<?php echo e($wishlist->id_wishlist); ?>)' class="btn btn-outline-danger px-5" type="button">
            <i class="fas fa-star fa-sm fa-fw"></i> Simpan
        </button>
        <?php else: ?>
        <button wire:click='love' class="btn btn-outline-primary px-5" type="button">
            <i class="fas fa-star fa-sm fa-fw"></i> Simpan
        </button>
        <?php endif; ?>
    </div>

    <div wire:ignore.self class="modal fade" id="myModals" data-bs-backdrop="static" data-bs-keyboard="false"
        tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Apply Lamaran Kerja</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="#" class="form-label d-flex">Resume Kamu <a href="<?php echo e(route('user.profile')); ?>"
                                class="ms-auto"><i class="fas fa-edit fa-sm fa-fw"></i></a></label>
                        <?php if($resume): ?>
                        <div class="form-control">
                            <a href="/documents/resume/<?php echo e($resume->resume); ?>" class="btn link-primary" download=""><?php echo e($resume->resume); ?></a>
                        </div>
                        <?php else: ?>
                        <div class="form-control is-invalid">Anda belum Upload Resume</div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="#" class="form-label d-flex w-100">Sertifikat <a href="<?php echo e(route('user.profile')); ?>"
                                class="ms-auto"><i class="fas fa-edit fa-sm fa-fw"></i></a></label>
                        <?php if($certificate): ?>
                        <div class="form-control">
                            <a href="/documents/certificate/<?php echo e($certificate->certificate); ?>" class="btn link-primary"
                                download=""><?php echo e($certificate->certificate); ?></a>
                        </div>
                        <?php else: ?>
                        <div class="form-control is-invalid">Anda belum Upload Sertifikat</div>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3 placeholder-glow">
                        <label class="form-label" for="description">Penjelasan Singkat</label>
                        <textarea wire:model='description' name="description" id="description" rows="4"
                            class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="Mengapa anda memilih pekerjaan ini."></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <?php if($resume and $certificate): ?>
                    <button wire:click.prevent="store" type="button" class="btn btn-primary" wire:target='apply'
                        wire:loading.remove>Apply Jobs</button>
                    <?php else: ?>
                    <button type="button" class="btn btn-secondary disabled" disabled>Apply Jobs</button>
                    <?php endif; ?>
                    <button class="btn btn-primary" type="button" disabled wire:loading.block wire:target='apply'
                        wire:target="store">
                        <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                        Loading...
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(url('/dist/style/js/jquery.js')); ?>"></script>
    <script>
        document.addEventListener('deleteConfrimed', function() {
    Swal.fire({
            title: "Apa anda yakin?",
            text: "Menghapus produk pesanan anda!!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: 'Yes, delete!',
            cancelButtonText: 'Tidak',
        })
        .then((next) => {
            if (next.isConfirmed) {
                Livewire.emit('deleteAction');
            }
        });
})

document.addEventListener('showModals', function() {
    $('#myModals').modal('show');
});

document.addEventListener('expandModals', function() {
    $('#myModals').modal('hide');
});
    </script>

    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
icon: 'success',
title: 'Good Jobs!',
text: '<?php echo e(session()->get("success")); ?>',
showConfirmButton: false,
timer: 2500
})
    </script>
    <?php elseif(session()->has('error')): ?>
    <script>
        Swal.fire({
icon: 'error',
title: 'Opps...!',
text: '<?php echo e(session()->get("error")); ?>',
showConfirmButton: false,
timer: 2500
})
    </script>
    <?php endif; ?>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/pages/loker/submit.blade.php ENDPATH**/ ?>