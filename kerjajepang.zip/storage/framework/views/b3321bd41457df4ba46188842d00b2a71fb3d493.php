

<?php $__env->startSection('head'); ?>
<title>kerja jepang - Profile Saya</title>
<style>
    .img-profile {
        width: 100%;
        height: 100%;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages'); ?>
<div class="pb-3 mt-5 pt-5">
    <div class="container">
        <div class="row g-2">
            <div class="col-12 col-lg-9 pe-0 pe-lg-4">

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.biodata')->html();
} elseif ($_instance->childHasBeenRendered('9ab7MWs')) {
    $componentId = $_instance->getRenderedChildComponentId('9ab7MWs');
    $componentTag = $_instance->getRenderedChildComponentTagName('9ab7MWs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9ab7MWs');
} else {
    $response = \Livewire\Livewire::mount('user.biodata');
    $html = $response->html();
    $_instance->logRenderedChild('9ab7MWs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.about')->html();
} elseif ($_instance->childHasBeenRendered('JADcNXh')) {
    $componentId = $_instance->getRenderedChildComponentId('JADcNXh');
    $componentTag = $_instance->getRenderedChildComponentTagName('JADcNXh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JADcNXh');
} else {
    $response = \Livewire\Livewire::mount('user.about');
    $html = $response->html();
    $_instance->logRenderedChild('JADcNXh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.experience')->html();
} elseif ($_instance->childHasBeenRendered('WtL3rSV')) {
    $componentId = $_instance->getRenderedChildComponentId('WtL3rSV');
    $componentTag = $_instance->getRenderedChildComponentTagName('WtL3rSV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WtL3rSV');
} else {
    $response = \Livewire\Livewire::mount('user.experience');
    $html = $response->html();
    $_instance->logRenderedChild('WtL3rSV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.education')->html();
} elseif ($_instance->childHasBeenRendered('38hPP7I')) {
    $componentId = $_instance->getRenderedChildComponentId('38hPP7I');
    $componentTag = $_instance->getRenderedChildComponentTagName('38hPP7I');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('38hPP7I');
} else {
    $response = \Livewire\Livewire::mount('user.education');
    $html = $response->html();
    $_instance->logRenderedChild('38hPP7I', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.skill')->html();
} elseif ($_instance->childHasBeenRendered('6lQ3c08')) {
    $componentId = $_instance->getRenderedChildComponentId('6lQ3c08');
    $componentTag = $_instance->getRenderedChildComponentTagName('6lQ3c08');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6lQ3c08');
} else {
    $response = \Livewire\Livewire::mount('user.skill');
    $html = $response->html();
    $_instance->logRenderedChild('6lQ3c08', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.resume')->html();
} elseif ($_instance->childHasBeenRendered('9BOoFxe')) {
    $componentId = $_instance->getRenderedChildComponentId('9BOoFxe');
    $componentTag = $_instance->getRenderedChildComponentTagName('9BOoFxe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9BOoFxe');
} else {
    $response = \Livewire\Livewire::mount('user.resume');
    $html = $response->html();
    $_instance->logRenderedChild('9BOoFxe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.certificate')->html();
} elseif ($_instance->childHasBeenRendered('1stJ7P1')) {
    $componentId = $_instance->getRenderedChildComponentId('1stJ7P1');
    $componentTag = $_instance->getRenderedChildComponentTagName('1stJ7P1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1stJ7P1');
} else {
    $response = \Livewire\Livewire::mount('user.certificate');
    $html = $response->html();
    $_instance->logRenderedChild('1stJ7P1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


            </div>
            <div class="col-12 col-lg-3">
                <div class="d-block rounded bg-white shadow mb-3">
                    <div class="px-2 py-1">
                        <p class="mb-0 fw-bold">Status Lamaran Aktif</p>
                    </div>
                    <div class="p-3">
                        <p class="text-secondary">Terdapat 2 lamaran aktif</p>
                    </div>
                </div>
                <div class="d-block rounded bg-white shadow mb-3">
                    <div class="p-3 border-bottom">
                        <p class="mb-0 fw-bold">Pilihan Cepat</p>
                    </div>
                    <div class="p-3">
                        <div class="row g-1">
                            <div class="col-6">
                                <a href="#" class="btn btn-outline-secondary d-block p-1 h-100">
                                    <i class="fas fa-file-import fa-2x fa-fw mb-2"></i>
                                    <p class="d-block mb-0">export to <br> Pdf</p>
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="#" class="btn btn-outline-secondary d-block p-1 h-100">
                                    <i class="fas fa-eye fa-2x fa-fw mb-2"></i>
                                    <p class="d-block mb-0">Lihat Profile Saya</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/user/profile.blade.php ENDPATH**/ ?>