<div>
    <div class="d-block rounded border mb-3">
        <div class="py-2 px-3 border-bottom">
            <p class="mb-0 fw-bold">Upload Document</p>
        </div>
        <div class="p-3">
            <div class="row g-3">
                <div class="col-12 col-md-6">
                    <label for="ktp" class="form-label">Upload KTP</label>
                    <label for="ktp" class="foto-upload mb-2">
                        <?php if($ktp): ?>
                        <img src="<?php echo e($ktp->temporaryUrl()); ?>" class="img-fluid">
                        <?php else: ?>
                        <i class="fas fa-plus fa-3x fa-fw text-secondary" wire:loading.remove wire:target='ktp'></i>
                        <?php endif; ?>
                        <div class="loading-stage" wire:loading.flex wire:target='ktp'>
                            <div class="spinner-border" role="status">
                                <span class="visually-hidden">Loading...</span>
                              </div>
                        </div>
                    </label>
                    <input wire:model='ktp' type="file" name="ktp" id="ktp" class="form-control  <?php $__errorArgs = ['ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 col-md-6">
                    <label for="kk" class="form-label">Upload KK</label>
                    <label for="kk" class="foto-upload mb-2">
                        <?php if($kk): ?>
                        <img src="<?php echo e($kk->temporaryUrl()); ?>" class="img-fluid">
                        <?php else: ?>
                        <i class="fas fa-plus fa-3x fa-fw text-secondary" wire:loading.remove wire:target='kk'></i>
                        <?php endif; ?>
                        <div class="loading-stage" wire:loading.flex wire:target='kk'>
                            <div class="spinner-border" role="status">
                                <span class="visually-hidden">Loading...</span>
                              </div>
                        </div>
                    </label>
                    <input wire:model='kk' type="file" name="kk" id="kk" class="form-control  <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 col-md-6">
                    <label for="photo" class="form-label">Upload foto</label>
                    <label for="photo" class="foto-upload mb-2">
                        <?php if($photo): ?>
                        <img src="<?php echo e($photo->temporaryUrl()); ?>" class="img-fluid">
                        <?php else: ?>
                        <i class="fas fa-plus fa-3x fa-fw text-secondary" wire:loading.remove wire:target='photo'></i>
                        <?php endif; ?>
                        <div class="loading-stage" wire:loading.flex wire:target='photo'>
                            <div class="spinner-border" role="status">
                                <span class="visually-hidden">Loading...</span>
                              </div>
                        </div>
                    </label>
                    <input wire:model='photo' type="file" name="photo" class="form-control  <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="photo">
                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 col-md-6">
                    <label for="akte" class="form-label">Upload akte kelahiran</label>
                    <label for="akte" class="foto-upload mb-2">
                        <?php if($akte): ?>
                        <img src="<?php echo e($akte->temporaryUrl()); ?>" class="img-fluid">
                        <?php else: ?>
                        <i class="fas fa-plus fa-3x fa-fw text-secondary" wire:loading.remove wire:target='akte'></i>
                        <?php endif; ?>
                        <div class="loading-stage" wire:loading.flex wire:target='akte'>
                            <div class="spinner-border" role="status">
                                <span class="visually-hidden">Loading...</span>
                              </div>
                        </div>
                    </label>
                    <input wire:model='akte' type="file" name="akte" class="form-control  <?php $__errorArgs = ['akte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="akte">
                    <?php $__errorArgs = ['akte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\safna\Documents\Kerjaan\project\kerjajepang\resources\views/livewire/pages/comer/documents.blade.php ENDPATH**/ ?>