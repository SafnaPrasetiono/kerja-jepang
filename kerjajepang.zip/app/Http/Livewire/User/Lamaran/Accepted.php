<?php

namespace App\Http\Livewire\User\Lamaran;

use Livewire\Component;

class Accepted extends Component
{
    public function render()
    {
        return view('livewire.user.lamaran.accepted');
    }
}
