<?php

namespace App\Http\Livewire\Admin\Galery;

use Livewire\Component;

class Paginations extends Component
{
    public function render()
    {
        return view('livewire.admin.galery.paginations');
    }
}
