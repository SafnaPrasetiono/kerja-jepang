<?php

namespace App\Http\Livewire\Admin\Qa;

use Livewire\Component;

class Paginations extends Component
{
    public function render()
    {
        return view('livewire.admin.qa.paginations');
    }
}
