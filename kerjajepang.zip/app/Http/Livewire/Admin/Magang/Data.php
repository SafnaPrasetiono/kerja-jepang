<?php

namespace App\Http\Livewire\Admin\Magang;

use App\Models\magang;
use Livewire\Component;
use Livewire\WithPagination;

class Data extends Component
{
    use WithPagination;
    public $id_magang;

    protected $listeners = ["deleteAction" => "delete"];

    public function removed($id){
        $this->id_magang = $id;
        $this->dispatchBrowserEvent('deleteConfrimed');
    }

    public function delete()
    {
        $data = magang::find($this->id_magang);
        if ($data) {
            $data->delete();
            return session()->flash('success', 'Data has been delete!');
        } else {
            return session()->flash('error', 'sorry something problem in database!');
        }
    }
    public function render()
    {
        $data = magang::orderBy('created_at', 'desc')->paginate(12);
        return view('livewire.admin.magang.data', [
            'data' => $data
        ]);
    }
}
