<?php

namespace App\Http\Livewire\Admin\Magang;

use App\Models\proposal_magang;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Livewire\Component;
use Livewire\WithPagination;

class Pelamar extends Component
{
    use WithPagination;

    public $id_magang;
    public $id_proposal;

    public $username, $resume, $certificate, $status, $description, $content;

    public function mount($id)
    {
        $this->id_proposal = $id;
    }

    public function detail($id)
    {
        $data = proposal_magang::find($id);
        $user = User::find($data->id_users);
        $this->username = $user->username;
        $this->status = $data->status;
        $this->description = $data->description;
        $this->resume = $data->resume;
        $this->certificate = $data->certificate;
        $this->dispatchBrowserEvent('showModals');
    }

    public function edit($id)
    {
        $data = proposal_magang::find($id);
        $user = User::find($data->id_users);
        $this->id_proposal = $id;
        $this->username = $user->username;
        $this->status = $data->status;
        $this->description = $data->description;
        $this->resume = $data->resume;
        $this->certificate = $data->certificate;
        $this->dispatchBrowserEvent('showEditModals');
    }

    public function store()
    {
        $data = proposal_magang::find($this->id_proposal);
        $data->status = $this->status;
        $data->content = $this->content;
        if($data->save()){
            session()->flash('success', 'Lamaran telah diinfokan ke user');
        }else{
            session()->flash('error', 'sorry database is busy');
        }
        $this->dispatchBrowserEvent('expandEditModal');
    }

    public function render()
    {
        $data = DB::table('view_proposal_magang')->where('id_proposal_magang', $this->id_proposal)->paginate(12);
        return view('livewire.admin.magang.pelamar', [
            'data'=> $data
        ]);
    }
}
