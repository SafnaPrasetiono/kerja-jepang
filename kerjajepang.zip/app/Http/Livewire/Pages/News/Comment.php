<?php

namespace App\Http\Livewire\Pages\News;

use Livewire\Component;

class Comment extends Component
{
    public function render()
    {
        return view('livewire.pages.news.comment');
    }
}
