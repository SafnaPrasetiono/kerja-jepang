<?php

namespace App\Http\Livewire\Pages\Index;

use App\Models\banner as ModelsBanner;
use Livewire\Component;

class Banner extends Component
{
    public function render()
    {
        $data = ModelsBanner::orderBy('created_at', 'desc')->get();
        return view('livewire.pages.index.banner', [
            'data' => $data
        ]);
    }
}
