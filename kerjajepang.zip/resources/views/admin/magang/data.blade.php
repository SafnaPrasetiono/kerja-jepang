@extends('admin.layouts.panel')

@section('head')
<title>kerjajepang - data magang kerja</title>
@endsection

@section('pages')
<div class="container-fluid">
    <div class="d-block rounded bg-white shadow">
        <div class="p-3 border-bottom">
            <p class="fs-4 fw-bold mb-0">Page Ex.Magang</p>
        </div>
        <div class="d-block p-3">
            @livewire('admin.magang.data')
        </div>
    </div>
</div>
@endsection

@section('script')

@endsection