<div>
        <div id="carouselBanners" class="carousel slide" data-bs-ride="carousel">
            {{-- <div class="carousel-indicators">
                @foreach ($data as $index => $item)
                <button type="button" data-bs-target="#carouselBanners" data-bs-slide-to="{{ $index }}"
                    class="@if($index == 0) active @endif" aria-current="true" aria-label="Slide {{ $index }}"></button>
                @endforeach
            </div> --}}
            <div class="carousel-inner">
                @foreach ($data as $index => $item)
                <div class="carousel-item @if($index == 0) active @endif">
                    <img src="{{ url('/images/banner/' . $item->banners_sm) }}"
                        class="d-block d-md-none w-100" alt="banners-1">
                    <img src="{{ url('/images/banner/' . $item->banners_lg) }}"
                        class="d-none d-md-block w-100" alt="banners-1">
                </div>
                @endforeach
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselBanners" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselBanners" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
</div>